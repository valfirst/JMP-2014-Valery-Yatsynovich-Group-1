package by.epam.filereadwrite;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class ReadWriter
{

	private static File file; 

	private static File getFile() throws IOException
	{
		if (file == null)
		{
			file = new File("abc.txt");
			file.createNewFile();
			file.deleteOnExit();
		}
		return file;
	}

	public static synchronized void writeToFile(String str) throws IOException, InterruptedException
	{
		System.out.println("Write: " + str);
		
		FileWriter writer = new FileWriter(getFile(), true);
		writer.write(str);
		writer.close();
	}
	
	public static synchronized void readFromFile() throws IOException
	{
		BufferedReader reader = new BufferedReader(new FileReader(getFile()));
		System.out.println("Read: " + reader.readLine());
		reader.close();
	}
}
